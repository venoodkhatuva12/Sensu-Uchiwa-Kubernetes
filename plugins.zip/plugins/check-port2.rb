#! /usr/bin/env ruby
exec ('/etc/sensu/plugins/check_ports.rb -H localhost -p 6077 -P tcp')
