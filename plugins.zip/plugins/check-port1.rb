#! /usr/bin/env ruby
exec ('/etc/sensu/plugins/check_ports.rb -H localhost -p 7077 -P tcp')
